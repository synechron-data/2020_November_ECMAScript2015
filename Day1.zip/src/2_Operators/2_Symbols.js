// const Read = "Read";
// const Write = "Write";

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open("Read");
// Open("Write");

// var rMode = "Read";
// Open(rMode);

// var wMode = "Write";
// Open(wMode);

// -----------------------------------------------------------------------

// const Read = { mode: "Read" };
// const Write = { mode: "Write" };

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "READ" mode');
//     else if (mode === Write)
//         console.log('File opened in "WRITE" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open({ mode: "Read" });
// Open({ mode: "Write" });

// var rMode = { mode: "Read" };
// Open(rMode);

// var wMode = { mode: "Write" };
// Open(wMode);

// ----------------------------------------------------------------------- Symbol

const Read = Symbol("Read");
const Write = Symbol("Write");

function Open(mode) {
    if (mode === Read)
        console.log('File opened in "READ" mode');
    else if (mode === Write)
        console.log('File opened in "WRITE" mode');
    else
        console.log('File cannot be opened');
}

Open(Read);
Open(Write);

Open(Symbol("Read"));
Open(Symbol("Write"));

var rMode = Symbol("Read");
Open(rMode);

var wMode = Symbol("Write");
Open(wMode);