// Type Casting - Between Similiar (Same Family of) Types int to float, float to int  [int a = (int)10.5]
// Type Conversion - Different Family of types                  int to string, string to float

// JavaScript supports only type Conversion

// var data = window.prompt("Enter a number", 0);
// // console.log(typeof data);

// var d1 = data + 10;
// console.log(d1);

// var d2 = parseInt(data) + 10;          // string to number
// console.log(d2);

// var d3 = parseFloat(data) + 10;        // string to number
// console.log(d3);

// var d4 = Number(data) + 10;            // any type to number
// console.log(d4);

// var obj;
// var obj = null;
// var obj = {};

// if ((obj === undefined) || (obj === null)) {
//     console.log("Is undefined or null");
// } else {
//     console.log("Is not undefined or not null");
// }

// if (!obj) {
//     console.log("Is undefined or null");
// } else {
//     console.log("Is not undefined or not null");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean({}));

console.log(true && "ABC");
console.log(true && "ABC" || "XYZ");
console.log(false && "ABC" || "XYZ");