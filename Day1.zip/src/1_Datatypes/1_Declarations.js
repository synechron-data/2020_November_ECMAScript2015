// If we donot want variables to be created automatically in the Global Scope
// Add 'use strict' manually on first line of every js files
// or
// use @babel/plugin-transform-strict-mode plugin when your are compiling through babel

// console.log("Hello from Declarations.js");

// a = 10;
// console.log("a is: ", a);

// function test() {
//     a = 10;
//     console.log("Inside test, a is:", a);
// }

// test();
// console.log("Outside test, a is:", a);

// var a
// a = 10;
// console.log("a:", a);

// var b = 20;
// console.log("b:", b);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// a = 10;
// console.log("a:", a);
// var a;

// Definitions or Initializations are not hoisted
// console.log("b:", b);
// var b = 20;

// Runtime will see the below code
// var b;
// console.log("b:", b);
// b = 20

// var a = 10;
// console.log("a:", a);

// a = "Manish";
// console.log("a:", a);

// a = true;
// console.log("a:", a);

// a = new Object();
// console.log("a:", a);

// var a = 10;
// var a = "Abhijeet";
// console.log("a:", a);