// Lexical Scoping - A lexical scope in JavaScript means that a variable defined outside a function can be accessible 
// inside another function defined after the variable declaration.

// var a = 10;
// console.log("Global, a:", a);

// function test() {
//     console.log("Inside test, a:", a);
// }

// test();

// function test1() {
//     function test2() {
//         console.log("Inside test 2, a:", a);
//     }
//     test2()
// }

// test1();

// ---------------------------------------------------------

// var a = 10;
// console.log("Global, a:", a);

// // function test() {
// //     var a = 1000;
// //     console.log("Inside test, a:", a);
// // }

// // test();

// function test1() {
//     var a = 1000;
//     function test2() {
//         var a = 2000;
//         console.log("Inside test 2, a:", a);
//     }
//     test2()
// }

// test1();

// console.log("Last Line, Global, a:", a);

// ---------------------------------------------------------------------------------------

// Scopes in ES 5 and earlier
// 1. Function (Local) Scope
// 2. Global Scope

// var i = "Hello";
// console.log("Before, i is:", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, i is", _i);
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }

// iterate();

// IIFE - Immediatly Invoked Function Expression
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is:", i);

// -----------------------------------------------------
// Scopes in ES 2015 and above
// 1. Block Scope
// 2. Function (Local) Scope
// 3. Global Scope

var i = "Hello";
console.log("Before, i is:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is:", i);