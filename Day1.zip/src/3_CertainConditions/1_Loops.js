// 5 kinds of loops

// for      - Iterates a block of code specified number of time
// for/in   - Iterating the properties of an object
// for/of   - Iterating the values of an iterable (string and array) object (ES 2015)
// while    - Iterates a block of code specified condition is true
// do/while - Also Iterates a block of code specified condition is true

// for (let i = 0; i < 5; i++) {
//     console.log("i,", i);
// }

// for (let i = 0, j = 10; i < 5; i++, j++) {
//     if (i === 2) {
//         // break;
//         continue;
//     }

//     console.log(`i: ${i}    j: ${j}`);
// }

// for (let i = 5; i > 0; i--) {
//     console.log("i,", i);
// }

// --------------------------------------------------- ForIn
// var person = { fname: "Manish", lname: "Sharma", city: "Pune" };
// // console.log(typeof person);

// for(const key in person){
//     console.log(`${key}         ${person[key]}`);
// }

// var numbers = [10, 20, 30, 40, 50, 60, 70, 80];
// console.log(typeof numbers);

// for (let i = 0; i < numbers.length; i++) {
//     console.log(`${i}         ${numbers[i]}`);
// }

// for (const key in numbers) {
//     console.log(`${key}         ${numbers[key]}`);
// }

// ----------------------------------------------------- For Of (Itearte an Iterable)
// var numbers = [10, 20, 30, 40, 50, 60, 70, 80];

// // for (const item of numbers) {
// //     console.log(item);
// // }

// for (const item of numbers.entries()) {
//     console.log(`${item[0]}         ${item[1]}`);
// }

// ------------------------------------------------------ While

// var i = 0;
// var i = 5;
// while (i < 5) {
//     console.log(i);
//     i++;
// }

// ------------------------------------------------------ Do While

// var i = 0;
// var i = 5;
// do {
//     console.log(i);
//     i++;
// } while (i < 5);