// ------------------------------------------- With Primitive
// var a = 100;

// function modify(data) {
//     data = 1000;
//     console.log(`Inside - ${data}`);
// }

// console.log(`Before - ${a}`);
// modify(a);
// console.log(`After - ${a}`);

// ------------------------------------------- With Complex
// var a = [10, 20, 30];

// function modify(data) {
//     data[0] = 1000;
//     console.log(`Inside - ${data}`);
// }

// console.log(`Before - ${a}`);
// modify(a);
// console.log(`After - ${a}`);


// --------------------------------------------------  
// var a = [10, 20, 30];

// // // Impure
// // function append(dataArr, x){
// //     dataArr[dataArr.length] = x;
// //     return dataArr;
// // }

// // Pure
// function append(dataArr, x) {
//     var rArr = [...dataArr];
//     rArr[dataArr.length] = x;
//     return rArr;
// }

// var newArr1 = append(a, 100);           // [10, 20, 30, 100]
// console.log(newArr1);

// var newArr2 = append(a, 100);           // [10, 20, 30, 100]
// console.log(newArr2);

// -------------------------------------------------------------- Assignment
var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    var result = [];

    for (const item of dataArr) {
        if (item.startsWith(x))
            result.push(item);
    }

    return result;
}

// function filter(dataArr, x) {
//     return dataArr.filter(item => item.startsWith(x));
// }

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);