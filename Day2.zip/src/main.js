// import './1_Functions/1_Assignment';
// import './1_Functions/2_FnContext';
// import './1_Functions/3_FnCurrying';

// import './2_Objects/1_ObjectCreation';
// import './2_Objects/2_ObjectType';
// import './2_Objects/3_ObjectMethods';
// import './2_Objects/4_CustomTypes';
// import './2_Objects/5_UsingPrototype';
// import './2_Objects/6_ES6_Class';
// import './2_Objects/7_Compare';
// import './2_Objects/8_ES5_Properties';
// import './2_Objects/9_ES6_Properties';
// import './2_Objects/10_ES6_StaticMembers';
// import './2_Objects/11_ES5_Inheritance';
// import './2_Objects/12_ES6_Inheritance';

// import './3_Collections/1_Array';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';
// import './3_Collections/4_WeakMap';

// import './4_Iterators/1_Iterators';
// import './4_Iterators/2_Generators';

// import './5_Modules/usage';

// import './6_Promise/1_CreatingPromise';
// import './6_Promise/2_ChainingPromise';
// import './6_Promise/3_PromiseMethods';
import './6_Promise/4_Query';

// import './6_Promise/domHandler';