// function greetings(message, name) {
//     return `${message}, ${name}`;
// }

// console.log(greetings("Good Morning", "Abhijeet"));
// console.log(greetings("Good Morning", "Ramakant"));
// console.log(greetings("Good Morning", "Pravin"));

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 71, 0, 100));
// console.log(Converter(" INR", 71, 0, 150));
// console.log(Converter(" INR", 71, 0, 290));
// console.log(Converter(" INR", 71, 0, 1000));

// --------------------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         return `${message}, ${name}`;
//     }
// }

// var mGreet = greetings("Good Morning");

// console.log(mGreet("Abhijeet"));
// console.log(mGreet("Ramakant"));
// console.log(mGreet("Pravin"));

// var aGreet = greetings("Good Afternoon");

// console.log(aGreet("Abhijeet"));
// console.log(aGreet("Ramakant"));
// console.log(aGreet("Pravin"));

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var usdToInr = Converter(" INR", 71, 0);

// console.log(usdToInr(100));
// console.log(usdToInr(150));
// console.log(usdToInr(290));
// console.log(usdToInr(1000));

// var mileToKm = Converter(" Km", 1.6, 0);

// console.log(mileToKm(100));
// console.log(mileToKm(150));
// console.log(mileToKm(290));
// console.log(mileToKm(1000));

// ------------------------------------------------------------------------------

// function greetings(message, name) {
//     return `${message}, ${name}`;
// }

// var mGreet = greetings.bind(undefined, "Good Morning");

// console.log(mGreet("Abhijeet"));
// console.log(mGreet("Ramakant"));
// console.log(mGreet("Pravin"));

// var aGreet = greetings.bind(undefined, "Good Afternoon");

// console.log(aGreet("Abhijeet"));
// console.log(aGreet("Ramakant"));
// console.log(aGreet("Pravin"));

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var usdToInr = Converter.bind(undefined, " INR", 71, 0);

console.log(usdToInr(100));
console.log(usdToInr(150));
console.log(usdToInr(290));
console.log(usdToInr(1000));

var mileToKm = Converter.bind(undefined, " Km", 1.6, 0);

console.log(mileToKm(100));
console.log(mileToKm(150));
console.log(mileToKm(290));
console.log(mileToKm(1000));