function CL_Counter(by) {
    var count = 0;
    var by = by;

    return {
        next: function () {
            return count += by;
        },
        prev: function () {
            return count -= by;
        }
    };
}

function FN_Counter(by) {
    this._count = 0;
    this._by = by;

    this.next = function () {
        return this._count += this._by;
    }

    this.prev = function () {
        return this._count -= this._by;
    }
}

const PT_Counter = (function () {
    function PT_Counter(by) {
        this._count = 0;
        this._by = by;
    }

    PT_Counter.prototype.next = function () {
        return this._count += this._by;
    }

    PT_Counter.prototype.prev = function () {
        return this._count -= this._by;
    }

    return PT_Counter;
})();

class CCounter {
    constructor(by) {
        this._count = 0;
        this._by = by;
    }

    next() {
        return this._count += this._by;
    }

    prev() {
        return this._count -= this._by;
    }
}

(function () {
    var clStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj = CL_Counter(i);
    }
    var clEnTime = new Date();

    var fnStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj1 = new FN_Counter(i);
    }
    var fnEnTime = new Date();

    var ptStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj2 = new PT_Counter(i);
    }
    var ptEnTime = new Date();

    var cStTime = new Date();
    for (let i = 0; i < 200000; i++) {
        var obj3 = new CCounter(i);
    }
    var cEnTime = new Date();

    var clTime = clEnTime.getTime() - clStTime.getTime();
    var fnTime = fnEnTime.getTime() - fnStTime.getTime();
    var ptTime = ptEnTime.getTime() - ptStTime.getTime();
    var cTime = cEnTime.getTime() - cStTime.getTime();

    console.log("Closure: ", clTime, "ms");
    console.log("Function: ", fnTime, "ms");
    console.log("Prototype: ", ptTime, "ms");
    console.log("Class: ", cTime, "ms");
})();