// var obj1 = null;
// console.log(obj1);
// console.log(typeof obj1);

// var obj2 = new Object();
// console.log(obj2);
// console.log(typeof obj2);

// var obj3 = {};
// console.log(obj3);
// console.log(typeof obj3);

// JavaScript Object (Value)
var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune",
        state: "MH"
    },
    display: function () {
        console.log("Person Display called...");
    }
};

console.log(person);
console.log(typeof person);

var person_JSON = JSON.stringify(person);

console.log(person_JSON);
console.log(typeof person_JSON);

var p = JSON.parse(person_JSON);

console.log(p);
console.log(typeof p);

