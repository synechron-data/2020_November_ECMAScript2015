// function* idGenerator() {
//     yield 1;
//     yield 2;
//     yield 3;
// }

// let seq = idGenerator();

// for (let i = 0; i < 5; i++) {
//     console.log(seq.next());
// }

// do {
//     var obj = seq.next();
//     console.log(obj.value);
// } while (!obj.done);

// do {
//     var { value, done } = seq.next();
//     console.log(value);
// } while (!done);


// for (const item of idGenerator()) {
//     console.log(item);
// }

// function fibonacci(n) {
//     let [a, b] = [0, 1];

//     let result = []
//     while (a < n) {
//         result.push(a);
//         [a, b] = [b, a + b];
//     }

//     return result;
// }

function* fibonacci(n) {
    let [a, b] = [0, 1];

    while (a < n) {
        yield a;
        [a, b] = [b, a + b];
    }
}

for (const n of fibonacci(15)) {
    console.log(n);
}