import localAPI from './localAPI';

var button = document.createElement("button");
button.innerHTML = "GET DATA";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

// button.addEventListener("click", function () {
//     // console.log("Button Clicked....");

//     // localAPI.getAllPosts((data) => {
//     //     console.log(data);
//     // }, (eMsg) => {
//     //     console.error(eMsg);
//     // });

//     localAPI.getAllPostsUsingPromise().then((data) => {
//         console.log(data);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });


button.addEventListener("click", async function () {
    var data = await localAPI.getAllPostsUsingPromise();
    console.log(data);
});