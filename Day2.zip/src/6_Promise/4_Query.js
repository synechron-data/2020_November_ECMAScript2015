function getData() {
    return new Promise((resolve, reject) => {
        setInterval(function () {
            resolve(Math.random());
        }, 2000);
    });
}

var p = getData();
console.log(p);

p.then((n) => {
    console.log("Result: ", n);
}, (e) => {
    console.error(e);
});