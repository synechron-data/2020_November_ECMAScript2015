// The Promise object represents the eventual completion (or failure) of an asynchronous operation, and its resulting value.

// It allows you to associate handlers with an asynchronous action's eventual success value or failure reason. 
// This lets asynchronous methods return values like synchronous methods: instead of immediately returning the final value, 
// the asynchronous method returns a promise to supply the value at some point in the future.

var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("Hello, it is a success");
        reject("It is an error");
    }, 5000);
});

// promise.then(msg => { 
//     console.log("Success: ", msg) 
// }, emsg => {
//     console.error("Error: ", emsg) 
// });

// promise.then(msg => {
//     console.log("Success: ", msg)
// }).catch(emsg => {
//     console.error("Error: ", emsg)
// });

promise.then(msg => {
    console.log("Success: ", msg)
}).catch(emsg => {
    console.error("Error: ", emsg)
}).finally(() => {
    console.log("Finally always run's");
})